package com.appiekap.movietheater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovietheaterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovietheaterApplication.class, args);
	}
}